import 'package:flutter/material.dart';
import 'package:life_app/PageExtra/About.dart';
import 'package:life_app/PageExtra/Setting.dart';
import 'package:life_app/PageExtra/ContactUs.dart';
import 'package:life_app/PageUser/LoginPageUser.dart';
import 'package:life_app/PageHospital/LoginPageHospital.dart';



void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {  
    return MaterialApp(
      title: 'Life_App',
      theme: new ThemeData(
        primarySwatch: Colors.red,
      ),
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Center(
          child: Row(
          children: <Widget>[
            Text('                '),
            new Image.asset('images/LOGO_p2.png',fit: BoxFit.contain,height: 46.0,),
          ],
        ),
      ),
      ),
      drawer: new Drawer(
        child: ListView(
          children: <Widget>[
            /*new UserAccountsDrawerHeader(
              accountName: new Text("Hello"),
              accountEmail: new Text("user@gmail.com"),
              currentAccountPicture: new CircleAvatar(
                backgroundColor: Colors.white,
              ),
            ),*/
            new Divider(),
            new ListTile(
                title: new Text("Setting"),
                onTap: ()=> Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => PageSetting()))
            ),
            new ListTile(
                title: new Text("Contact Us"),
                onTap: ()=> Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => PageContact()))
            ),
            new ListTile(
                title: new Text("About"),
                onTap: ()=> Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => PageAbout()))
            ),
          ],
        ),
      ),
      body: Container(
        padding:const EdgeInsets.only(top:50.0),
        child: Center(
            child: Column(
              children: <Widget>[
                Container(
                  height: 150.0,
                  width: 150.0,
                  child: RaisedButton(
                    //padding: const EdgeInsets.all(30.0),
                    elevation: 8.0,
                    color: Colors.red,
                    shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(100.0)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.account_circle,size:50.0,color: Colors.white,),
                        Text("User",style: new TextStyle(fontSize: 26.0,color: Colors.white),)
                      ],
                    ),
                    onPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPageUser()),
                      );
                    },
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(80.0),
                  height: 150.0,
                  width: 150.0,
                  child: RaisedButton(
                    //padding: const EdgeInsets.all(30.0),
                    elevation: 8.0,
                    color: Colors.red,
                    shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(100.0)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.account_circle,size:50.0,color: Colors.white,),
                        Text("Hospital",style: new TextStyle(fontSize: 26.0,color: Colors.white),)
                      ],
                    ),
                    onPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPageHospital()),
                      );
                    },
                  ),
                ),
              ],
            )
        ),
      ),
    );
  }
}

