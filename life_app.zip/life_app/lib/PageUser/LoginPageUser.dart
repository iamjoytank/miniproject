import 'package:flutter/material.dart';
import 'package:life_app/PageUser/UserHomePage.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginPageUser extends StatefulWidget {
  final Widget child;

  LoginPageUser({Key key, this.child}) : super(key: key);

  _LoginPageUserState createState() => _LoginPageUserState();
}

class _LoginPageUserState extends State<LoginPageUser> {
  String _email,_password;
  final GlobalKey<FormState> _formkey =GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: Form(
        
        key:_formkey,
        child: Column(
          children: <Widget>[
            TextFormField(
              validator:(input){
                if(input.isEmpty){
                  return 'Please type an email';
                }
              } ,
              
              onSaved: (input)=>_email =input,
              decoration: InputDecoration(
                labelText: 'Email'
              ),
            ),
              TextFormField(
              validator:(input){
                if(input.length < 6){
                  return 'Your password needs to be atleast 6 charactors';
                }
              } ,
              onSaved: (input)=>_password =input,
              decoration: InputDecoration(
                labelText: 'Password'
              ),
            ),
            RaisedButton(
              onPressed: signIn,
              child: Text("Login"),
            ),
            FlatButton(
              onPressed:(){},
              child:Text("Forget Password?")
            ),
            FlatButton(
              onPressed: (){},
              child:Text("Sign Up")
            )
          ],
        ),
      ),
    );
  }

  Future<void> signIn() async {
    final formState =_formkey.currentState;
    if(formState.validate()){
      formState.save();
      try{
        FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email:_email,password:_password);
        print("Email: $_email password: $_password $user");
        Navigator.push(context, MaterialPageRoute(builder: (context) => UserHomePage()));
      }
      catch(e){
        print(e.message);
      }
    }
  }
}