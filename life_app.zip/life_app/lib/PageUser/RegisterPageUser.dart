import 'package:flutter/material.dart';

class RegisterPageUser extends StatefulWidget {
  @override
  _RegisterPageUserState createState() => _RegisterPageUserState();
}

class _RegisterPageUserState extends State<RegisterPageUser> {
  String _userName,_mobileNo,_emailId,_password;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text("Login"),
    ),
      body: Container(
        child: Form(
          child: Row(
            children: <Widget>[
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Enter your User Name"
                ),
                validator:(input){
                  if(input.isEmpty){
                    return 'Please type User name';
                  }
                } ,
                onSaved: (input)=> _userName = input,
              ),
              TextFormField(
                decoration: InputDecoration(
                    labelText: "Enter your EmailId"
                ),
                validator:(input){
                  if(input.isEmpty){
                    return 'Please type your EmailId';
                  }
                } ,
                onSaved: (input)=> _emailId = input,
              ),
              TextFormField(
                decoration: InputDecoration(
                    labelText: "Enter your Password"
                ),
                validator:(input){
                  if(input.length < 6){
                    return 'Please enter atleast 6 charactor';
                  }
                } ,
                onSaved: (input)=> _password = input,
              ),

            ],
          ),
        ),
      ),
    );
  }
}
