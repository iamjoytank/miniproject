import 'package:flutter/material.dart';

class UserHomePage extends StatefulWidget {
  @override
  _UserHomePageState createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  String city,nameofTreatmant;
  final GlobalKey<FormState> _formkey =GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Row(
            children: <Widget>[
              Text('                '),
              new Image.asset('images/LOGO_p2.png',fit: BoxFit.contain,height: 46.0,),
            ],
          ),
        ),
      ),
      body: Container(
        child: Form(

          key:_formkey,
          child: Column(
            children: <Widget>[
              TextFormField(
                validator:(input){
                  if(input.isEmpty){
                    return 'Enter your current city name';
                  }
                } ,
                onSaved: (input)=> city =input,
                decoration: InputDecoration(
                    labelText: 'City name '
                ),
              ),
              TextFormField(
                validator:(input){
                  if(input.isEmpty){
                    return 'Enter Treatment name ';
                  }
                } ,
                onSaved: (input)=> nameofTreatmant =input,
                decoration: InputDecoration(
                    labelText: 'Name of Treatment'
                ),
              ),

              RaisedButton(
                onPressed: ()=> Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => UserHomePage())),
                child: Text("Submit"),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
