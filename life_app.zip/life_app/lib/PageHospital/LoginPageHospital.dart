import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:life_app/PageHospital/HospitalHomePage.dart';


class LoginPageHospital extends StatefulWidget {
  final Widget child;

  LoginPageHospital({Key key, this.child}) : super(key: key);

  _LoginPageHospitalState createState() => _LoginPageHospitalState();
}

class _LoginPageHospitalState extends State<LoginPageHospital> {
  String _email,_password;
  final GlobalKey<FormState> _formkey =GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: Form(
        
        key:_formkey,
        child: Column(
          children: <Widget>[
            TextFormField(
              validator:(input){
                if(input.isEmpty){
                  return 'Please type an email';
                }
              } ,
              
              onSaved: (input)=>_email =input,
              decoration: InputDecoration(
                labelText: 'Email'
              ),
            ),
              TextFormField(
              validator:(input){
                if(input.length < 6){
                  return 'Your password needs to be atleast 6 charactors';
                }
              } ,
              onSaved: (input)=>_password =input,
              decoration: InputDecoration(
                labelText: 'Password'
              ),
            ),
            RaisedButton(
              onPressed: (){},
              child: Text("Log in"),
            ),
            FlatButton(
              onPressed:(){},
              child:Text("Forget Password?")
            ),
            FlatButton(
              onPressed:(){},
              child:Text("Sign Up")
            )
          ],
        ),
      ),
    );
  }

  Future<void> signIn() async {
    final formState =_formkey.currentState;
    if(formState.validate()){
      formState.save();
      try{
        FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email:_email,password:_password);
        print("Email: $_email password: $_password $user");
        Navigator.push(context, MaterialPageRoute(builder: (context) => HospitalHomePage()));
      }
      catch(e){
        print(e.message);
      }
    }
  }
}