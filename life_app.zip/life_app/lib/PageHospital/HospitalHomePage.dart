import 'package:flutter/material.dart';

class HospitalHomePage extends StatefulWidget {
  @override
  _HospitalHomePageState createState() => _HospitalHomePageState();
}

class _HospitalHomePageState extends State<HospitalHomePage> {
  //String city,nameofTreatmant;
  final GlobalKey<FormState> _formkey =GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Row(
            children: <Widget>[
              Text('                '),
              new Image.asset('images/LOGO_p2.png',fit: BoxFit.contain,height: 46.0,),
            ],
          ),
        ),
      ),
      body: Container(
//
      ),
    );
  }
}
